package de.hawhamburg.textgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TextgameApplicationTests {

	@Test
	void contextLoads() {
	}

}
