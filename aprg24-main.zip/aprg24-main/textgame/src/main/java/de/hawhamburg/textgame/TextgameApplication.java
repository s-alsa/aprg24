package de.hawhamburg.textgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextgameApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextgameApplication.class, args);
	}

}
