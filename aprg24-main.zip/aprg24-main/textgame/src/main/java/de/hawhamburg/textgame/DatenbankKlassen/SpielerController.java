package de.hawhamburg.textgame.DatenbankKlassen;

import org.springframework.stereotype.Controller;

@Controller
class SpielerController {

    private final SpielerRepository spielerRepository;

    CrudController(SpielerRepository spielerRepository) {
        this.spielerRepository = spielerRepository;
    }
}