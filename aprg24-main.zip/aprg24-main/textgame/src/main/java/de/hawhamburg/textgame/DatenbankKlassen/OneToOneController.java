package de.hawhamburg.textgame.DatenbankKlassen;


import ch.qos.logback.core.model.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;

public class OneToOneController {

    private final SpielerRepository spielerRepository;
    private final CharakterRepository charakterRepository;
    OneToOneController(SpielerRepository spielerRepository, CharakterRepository charakterRepository) {
        this.spielerRepository = spielerRepository;
        this.charakterRepository = charakterRepository;
        insertInitialDataToDatabase();
    }

    private void insertInitialDataToDatabase() {
    }

    @GetMapping("/one-to-one")
    String serveTemplate(Model model) {
        record SpielerWithCharakter(Spieler car, Charakter engine) {}
        var spielerWithCharakter = new ArrayList<SpielerWithCharakter>();
        for (Spieler spieler : spielerRepository.findAll()) {
            var charakter = charakterRepository.findById(charakter.SpielerId()).orElseThrow();
            spielerWithCharakter.add(new SpielerWithCharakter(spieler, charakter));
        }
        model.addAttribute("spielerWithCharakter", spielerWithCharakter);
        return "oneToOne";


    }
