package DatenbankKlassen;

import org.springframework.data.annotation.Id;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Repository;

public class Spieler {

    @Id
    private long id;
    private String username;
    private String passwort;
    private int spieldurchgang;
    private String status;

    public Spieler(long id) {
        this.id = id;
    }

    long id() {
        return id;
    }


}
