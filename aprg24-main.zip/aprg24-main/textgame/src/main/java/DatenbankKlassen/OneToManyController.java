package DatenbankKlassen;

public class OneToManyController {
}
